cyclocity = 'get your API key at http://developer.jcdecaux.com'
